from setuptools import setup
setup(name="packagearithmatic",
version="0.1",
description="Arithmatic Operators functions.",
Long_description="This package contains all Arithmatic operators function to use when ever need.",
author="MG-Mate",
packages=['packagearithmatic'],
install_requires=[]

)