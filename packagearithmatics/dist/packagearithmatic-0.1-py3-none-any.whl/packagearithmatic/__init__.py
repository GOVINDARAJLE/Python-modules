def add(a,b):
    Result=a+b
    return Result       
